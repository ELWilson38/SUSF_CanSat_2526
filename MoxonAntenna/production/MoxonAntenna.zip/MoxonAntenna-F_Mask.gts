G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.3*
G04 #@! TF.CreationDate,2025-09-22T13:10:58+01:00*
G04 #@! TF.ProjectId,MoxonAntenna,4d6f786f-6e41-46e7-9465-6e6e612e6b69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.3) date 2025-09-22 13:10:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
